<?php
//------------------------------------------------------------------------------
$DBfile = "D:/xampp/htdocs/Sensor/.db.sensors";
$SECURITYKEY = "23338d373027ce83b1f81b9e9563b629";
//------------------------------------------------------------------------------
// $Sensor[<nodeID>] = "<Place>";
$Sensor['19'] = "Wohnzimmer";
$Sensor['20'] = "Garage / Schuppen";
$Sensor['21'] = "Garten";
?>